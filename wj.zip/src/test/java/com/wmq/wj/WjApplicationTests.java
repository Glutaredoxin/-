package com.wmq.wj;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WjApplicationTests {

    @Test
    void contextLoads() {
    }

}
