package com.wmq.wj;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
/**
 * @author 王梦琼
 */
@SpringBootApplication
//启动类
public class WjApplication {
//SpringTestApplication类执行main方法，
// main方法调用SpringApplication的run方法。
    public static void main(String[] args) {
        SpringApplication.run(WjApplication.class, args);
    }

}
