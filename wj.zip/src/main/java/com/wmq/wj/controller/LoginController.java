package com.wmq.wj.controller;
import com.wmq.wj.pojo.User;
import com.wmq.wj.result.Result;
import com.wmq.wj.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.util.HtmlUtils;

import java.util.Objects;

/**
 * @author 王梦琼
 */
@RestController
//LoginController 类充当请求控制器
public class LoginController {
    @Autowired
    UserService userService;

    @CrossOrigin
    @PostMapping(value = "api/login")
    @ResponseBody
    public Result login(@RequestBody User requestsUser){
        String username = requestsUser.getUsername();
        username = HtmlUtils.htmlEscape(username);
        //防止xss攻击
        User user = userService.get(username,requestsUser.getPassword());
        if(user==null){
            String message = "账号或者密码错误";
            System.out.println("test"+message);
            System.out.println("error失败");
            return new Result(400);
        } else{
            System.out.println("成功");
            return new Result(200);
        }
    }
}
