package com.wmq.wj.dao;

import com.wmq.wj.pojo.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * @author 王梦琼
 */
@Repository
public interface UserDAO extends JpaRepository<User,Integer> {
    //使用了JPA,无需手动创建sql语句,按照规范提供方法名就可以
    User findByUsername(String username);
    User getByUsernameAndPassword(String username,String password);
}
