import Vue from 'vue'
import Router from 'vue-router'
import Login from '@/components/Login'
import Appindex from '@/components/home/Appindex'
import page1 from '@/components/markets/page1'

Vue.use(Router)
//定义外面访问资源的url路径，相对路径
export default new Router({
  routes: [
    {
      path: '/login',
      name: 'Login',
      component: Login
    },{
      path: '/index',
      name: 'Appindex',
      component: Appindex
    },//配置各个component的显示路径
    {
      path: '/page1',
      name: 'page1',
      component: page1
    }//配置各个component的显示路径
  ]
})
