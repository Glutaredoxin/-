<template>
  <div>
    Hello,Vue!
  </div>

</template>

<script>
    export default {
        name: "Appindex"
    }
</script>

<style scoped>

</style>
