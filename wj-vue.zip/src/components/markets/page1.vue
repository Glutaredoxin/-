<template>
  <el-container style="height: 500px; border: 1px solid #eee">
    <el-aside width="200px" style="background-color: rgb(238, 241, 246)">
      <el-menu :default-openeds="['1', '3']">
        <el-submenu index="1">
          <template slot="title"><i class="el-icon-menu"></i>采购</template>
          <el-menu-item-group>
            <el-menu-item index="1-1">入库单</el-menu-item>
            <el-menu-item index="1-2">供应商表</el-menu-item>
          </el-menu-item-group>
        </el-submenu>
        <el-submenu index="2">
          <template slot="title"><i class="el-icon-menu"></i>销售</template>
            <el-menu-item index="2-1">出库单</el-menu-item>
            <el-menu-item index="2-2">商品定价</el-menu-item>
        </el-submenu>

        <el-submenu index="3">
          <template slot="title"><i class="el-icon-menu"></i>退货</template>
            <el-menu-item index="3-1">退货单</el-menu-item>
        </el-submenu>

        <el-submenu index="4">
          <template slot="title"><i class="el-icon-menu"></i>商品</template>
            <el-menu-item index="4-1">商品分类</el-menu-item>
            <el-menu-item index="4-2">库存账</el-menu-item>
            <el-menu-item index="4-3">库存流水账</el-menu-item>
        </el-submenu>

        <el-submenu index="5">
          <template slot="title"><i class="el-icon-menu"></i>财务</template>
            <el-menu-item index="5-1">尚未结清款项</el-menu-item>
            <el-menu-item index="5-2">支付流水账</el-menu-item>
            <el-menu-item index="5-3">盈亏分析</el-menu-item>
        </el-submenu>

        <el-submenu index="6">
          <template slot="title"><i class="el-icon-menu"></i>员工</template>
            <el-menu-item index="6-1">角色权限</el-menu-item>
            <el-menu-item index="6-2">员工基本信息</el-menu-item>
        </el-submenu>

        <el-submenu index="7">
          <template slot="title"><i class="el-icon-setting"></i>系统</template>
            <el-menu-item index="7-1">登录账号</el-menu-item>
            <el-menu-item index="7-2">我家超市</el-menu-item>
            <el-menu-item index="7-3">日志查询</el-menu-item>
        </el-submenu>
      </el-menu>
    </el-aside>

    <el-container>
      <el-header style="text-align: right; font-size: 12px">
        <el-dropdown>
          <i class="el-icon-setting" style="margin-right: 15px"></i>
          <el-dropdown-menu slot="dropdown">
            <el-dropdown-item>查看</el-dropdown-item>
            <el-dropdown-item>新增</el-dropdown-item>
            <el-dropdown-item>删除</el-dropdown-item>
          </el-dropdown-menu>
        </el-dropdown>
        <span>乐多超市</span>
      </el-header>

      <el-main>
        <el-table :data="tableData">
          <el-table-column prop="inumber" label="入库单号" width="140">
          </el-table-column>
          <el-table-column prop="gid" label="商品代码" width="120">
          </el-table-column>
          <el-table-column prop="vname" label="供应商名称">
          </el-table-column>
          <el-table-column prop="idate" label="入库日期">
          </el-table-column>
          <el-table-column prop="iprice" label="价格">
          </el-table-column>
          <el-table-column prop="ipayment" label="已付款项">
          </el-table-column>
          <el-table-column prop="icount" label="数量">
          </el-table-column>
        </el-table>
      </el-main>
    </el-container>
  </el-container>
</template>

<script>
    export default {
        name: "page1",
        data() {
            const item = {
                inumber:'2019110337',
                gid: '1000100023',
                vname: '蒙牛',
                idate: '2020-04-17',
                iprice:'17.98',
                ipayment:'79.99',
                icount:'4'
            };
            return {
                tableData: Array(3).fill(item)
            }
        }
    }
</script>
<style scoped>
  .el-header {
    background-color: #B3C0D1;
    color: #333;
    line-height: 60px;
  }
  .el-aside {
    color: #333;
  }
</style>
